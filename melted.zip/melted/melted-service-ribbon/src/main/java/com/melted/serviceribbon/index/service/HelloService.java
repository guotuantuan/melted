package com.melted.serviceribbon.index.service;

/**
 * @Author:gtt
 * @Description
 * @Date: 2019/5/23 15:01
 */

public interface HelloService {


    public String hiService(String name);
}
