package com.melted.serviceribbon.index;

/**
 * @Author:gtt
 * @Description
 * @Date: 2019/5/23 15:01
 */
public class test {
}
